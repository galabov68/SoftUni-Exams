package spaceStation.models.planets;

import java.util.Collection;

public interface Planet {
    Collection<String> getItems();

    String getName();
}
